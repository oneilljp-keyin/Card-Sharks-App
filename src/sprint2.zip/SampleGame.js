import React from 'react'
import { Link } from 'react-router-dom';
import "./App.css";
import Logo from "./Card_Sharks_2019_logo.png";
import layout from "./sergio-ruiz-WetGvQxnbYY-unsplash (1).jpg";



function SampleGame() {
    function btn () {
        return
    }


    return (
        <div className="App">
            <div className="main-box">
            <img src={Logo} />
                <div className="GameRules">
                    <div>Bank Total</div>
                    <button className="gold-button" onClick={btn} id='button'>$15,000</button>
                    <div>Base Number </div>
                    <button className="gold-button" onClick={btn} id='button'>*****</button>
                    <div>Wager </div>
                    <button className="gold-button" onClick={btn} id='button'>$1500</button>
                        <div>Minimum </div>
                    <button className="gold-button" onClick={btn} id='button'>Wow you won!!!</button>
                        <div>You guessed right</div>
                            <button className="gold-button" onClick={btn} id='button2'>Next</button>
                            <button button color= "blue" text="bye" />
                        
                </div>
            
            </div>
        </div>
    )
}

export default SampleGame;
