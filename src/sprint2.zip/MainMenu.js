import React from 'react'
import { Link } from 'react-router-dom';
import "./App.css";
import Logo from "./Card_Sharks_2019_logo.png";


function MainMenu() {
    function btn ({ color, text }) {
        return (
            <button style = {{backgroundColor: color}}
            className = "bnt">
                {text}
            </button>
        )
    }


    return (
        <div className="App">
            <div className="main-box">
                <img src={Logo} />
                <div>This is the main page</div>
                <div><Link to="/Game">Game</Link></div>
                <div><Link to="/Infoscreen">Infoscreen</Link></div>
                <div><Link to="/Score">Score</Link></div>
                <div><Link to="/SampleGame">SampleGame</Link></div>
                <div><Link to="/GameBank">GameBank</Link></div>
                <div>Username</div>
                <input id="username" placeholder="@jonny200" />
                <button className="gold-button" onClick={btn} id='button'>Click to start game</button>
                <button className="gold-button" onClick={btn} id='button2'>Game scores</button>
            
            </div>
        </div>
    )
}

export default MainMenu
