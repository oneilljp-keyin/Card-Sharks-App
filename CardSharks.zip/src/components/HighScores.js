import React from 'react'

function HighScores() {
  return (
    <div className="header">
      <h1>These are the High Scores</h1>
    </div>
  )
}

export default HighScores
